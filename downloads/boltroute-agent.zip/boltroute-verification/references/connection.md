# Connect Bolt Route

MCP endpoint, available after the customer MCP integration release: `https://api.boltroute.ai/mcp`.

Create or access your current account from the [customer sign-up page](https://app.boltroute.ai/agents?mode=signup). You can use Google or email and password; email/password accounts must verify their email before signing in. If you used the previous sign-in system, create a fresh account. Its account ID is new; previous sessions, passwords, password-reset links, task history and API credits are not imported or matched by email.

Self-service credit purchases for accounts created through Agents are not yet available. Check the current API balance and contact support to confirm credit availability before paid work. Checkout from the previous sign-in system does not fund this account.

In the customer console, open [Agents](https://app.boltroute.ai/agents). Use browser authorization or create an expiring token with the permissions you need. `verification:write` permits chargeable submissions; read-only work needs `verification:read`, and balance/usage needs `credits:read`. Copy a newly created token once into a local secret store or the `BOLTROUTE_API_KEY` environment variable, never a chat prompt or shared configuration.

For Codex with a token:

```sh
codex mcp add boltroute-verification --url https://api.boltroute.ai/mcp --bearer-token-env-var BOLTROUTE_API_KEY
```

For Codex browser authorization:

```sh
codex mcp add boltroute-verification --url https://api.boltroute.ai/mcp
codex mcp login boltroute-verification
```

For Claude Code browser authorization:

```sh
claude mcp add --transport http boltroute-verification https://api.boltroute.ai/mcp
```

Run `/mcp` in Claude Code to authenticate and inspect the connection. For a token, copy [`claude-token.json`](../../claude-token.json) to your project root as `.mcp.json`; Claude Code expands `${BOLTROUTE_API_KEY}` in HTTP headers from the local environment. Do not commit a resolved token. A direct `--header "Authorization: Bearer ${BOLTROUTE_API_KEY}"` command stores the resolved credential in local client configuration.

Email/password sign-in requires a verified email. Complete verification, then restart agent authorization if the request expired. Inspect the client callback and requested scopes before approving. Disconnecting from **Agents** revokes the grant and its tokens. Deleting local client configuration alone does not revoke server access.

If connection fails: check endpoint/feature availability, sign-in, expiry/revocation, permissions and the server's retry timing. An insufficient-credit error requires available API credits. A provider hold or unknown verification result should be reported as such, not retried with a fresh request ID. Share safe request/task IDs with support; keep credentials and recipient datasets private.

References: [customer guide](https://docs.boltroute.ai/integrations/agents), [Codex MCP](https://learn.chatgpt.com/docs/extend/mcp?surface=cli), [Claude Code MCP](https://code.claude.com/docs/en/mcp).
