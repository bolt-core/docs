---
name: boltroute-verification
description: Verify email addresses, follow verification tasks, retrieve customer results and inspect credits through the Bolt Route customer MCP connection.
---

Use the connected `boltroute-verification` MCP server. If it is unavailable, check whether the customer MCP integration has been released and read [connection setup](references/connection.md); never ask the customer to paste a token into chat.

Customers must use their current account at https://app.boltroute.ai/agents?mode=signup. Email/password sign-ups must verify the email address before sign-in. If someone used the previous sign-in system, direct them to create a fresh account; do not claim previous sessions, passwords, password-reset links, task history or API credits transfer or match by email. Check the current credit balance before paid work.

Self-service credit purchases for accounts created through Agents are not yet available. Check the current API balance and contact support to confirm credit availability before paid work. Checkout from the previous sign-in system does not fund this account. Do not invent a purchase flow, transfer balances or grant credits.

Use `get_credit_balance` and existing task/history reads when useful. An explicit request to verify specified addresses authorizes that verification work within the connection's permissions. Explain the chargeable action before submitting if the request was only exploratory. Respect workload authorization and credit/account limits; never request operator access or force SMTP traffic.

For a single address use `verify_email`; for a list use `create_verification_task`. Supply one stable `request_id` per intended submission and retain it with the returned task ID. A matching retry must use the same ID and body. After a timeout or uncertain outcome, resume/poll that operation rather than inventing a new request ID. A new request ID is a new potentially chargeable operation.

Use `get_verification_task` to poll at a bounded interval and `get_verification_results` for bounded pages. If a transient API error includes `retry_after_seconds`, wait at least that long. Continue from the returned offset until the requested range is covered; do not silently report a first page as the whole list. `list_verification_tasks` provides customer history. `get_verification_export` returns a download URL requiring the customer's authenticated connection; do not append credentials to it or publish it with recipient data.

Report the API's exact `valid`, `invalid`, `catchall`, `invalid_syntax`, `disposable_domain`, `typo_domain` and `unknown` classifications, public reasons and task progress. Keep pending/processing/failed job states distinct from verification results. Catch-all, unknown, a provider timeout or a rate limit is not proof that a mailbox is valid or invalid. Do not promise delivery. Domain checks are the observed fields on the customer's verification results; do not claim a fresh check when the status is `not_checked`.

Use `get_credit_usage` for customer usage. Do not expose global email/domain datasets, proxy pools, provider credentials, policy administration or production controls. Cancellation and forced retries are unavailable unless a future discovered tool explicitly supports them.

If permission is missing, direct the customer to **Agents** in the customer console at https://app.boltroute.ai/agents to grant only the needed scope. For an expired or revoked connection, reconnect with browser consent or a new scoped token. Keep browser sessions and agent tokens separate.
