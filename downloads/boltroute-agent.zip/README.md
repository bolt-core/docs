# Bolt Route customer agent package

This package contains optional portable skill instructions and credential-free MCP configuration. The running customer MCP endpoint supplies the tools; installing the skill alone does not connect an agent.

## Customer account

Create or access your current account from the [customer sign-up page](https://app.boltroute.ai/agents?mode=signup). You can use Google or email and password; email/password accounts must verify their email before signing in.

If you used the previous sign-in system, create a fresh account. Its account ID is new, and previous sessions, passwords, password-reset links, task history and API credits are not imported or matched by email. Check the current account's credit balance before submitting paid work. The MCP endpoint and browser connection flow are available only after the customer MCP integration release.

Self-service credit purchases for accounts created through Agents are not yet available. Check the current API balance and contact support to confirm credit availability before paid work. Checkout from the previous sign-in system does not fund this account.

From this extracted package folder, install the skill in your own project:

```sh
mkdir -p .agents/skills
cp -R boltroute-verification .agents/skills/
```

Codex discovers `.agents/skills` in a project. For Claude Code, use `.claude/skills` instead. These copies affect only the selected project. Do not overwrite an existing customized installation without reviewing it.

Follow `boltroute-verification/references/connection.md` to add the actual MCP connection. The TOML files and `claude-token.json` are optional examples; merge only the chosen server entry with your existing client configuration. For Claude Code, copy `claude-token.json` to your project root as `.mcp.json` and provide `BOLTROUTE_API_KEY` through your local environment or secret store. The examples contain no credential. OAuth examples require an enabled, deployed browser-consent endpoint.

Example prompts:

- “Show my credit balance and recent verification tasks.”
- “Verify these addresses that I am authorized to process, then report unknown results separately.”
- “Resume task `<task-id>` and retrieve the next 100 results.”
- “Get an authenticated CSV export for my completed task.”

Revoke server access from **Agents** in the [customer console](https://app.boltroute.ai/agents) when finished. These setup instructions cover Claude Code.
